package Utilizadores;

public class UtilizadorJaExiste extends Exception {

    public UtilizadorJaExiste(){
        super();
    }

    public UtilizadorJaExiste(String m){
        super(m);
    }
}