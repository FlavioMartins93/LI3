package Utilizadores;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;


/**
* Esta classe implementa uma lista de ids de utilizadores ordenada por reputaçao ou total de posts
* 
* @author (seu nome) 
* @version 1.0
*/

public class ListaParIdOrd
{
	// variáveis de instância
	private List<ParIdOrd> lista = new ArrayList<ParIdOrd>();        /*Lista de pares (Id,Ord) em que Ord corresponde ao 
																					criterio de ordenaçao, reputação ou total de posts */
	/** Construtor para objetos da classe ListaUtilizadores	*/
	public void ListaParIdOrd()
	{
		lista = new ArrayList<ParIdOrd>();
	}

	public List<ParIdOrd> getListaParIdOrd() {
		return this.lista;
	}
	//adiciona um par a lista
	public void inserirNovoParIdOrd(ParIdOrd par)
	{
		this.lista.add(par);
	}

	//ordena a lista
	public void sortListaParIdOrd()
	{
	   Collections.sort(this.lista);
	}

	public void printLista()
	{
		int i = 0;
		for(ParIdOrd par : this.lista)
		{
			System.out.println("Id: " + par.getId() + "  |  Total de posts: " + par.getOrd());
			i++;
			if(i==50) break;
		}

	}
}
