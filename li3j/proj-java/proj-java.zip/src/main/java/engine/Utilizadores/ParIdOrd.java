package Utilizadores;

import java.lang.Object;
import static java.lang.Math.toIntExact;


/**
 * classe que define um par contendo o Id e reputaçao/total de posts dum utilizador
 * 
 * @author Flavio Martins, Mario Santos, Pedro Costa 
 * @version 1.0
 */
public class ParIdOrd implements Comparable<ParIdOrd>
{
    // variáveis de instância
    private long id;                         //id do utilizador
    private long ord;                        //long correspondente ao criterio de ordenação

    /**
     * COnstrutor para objetos da classe UtilParIdRep
     */
    public void ParIdOrd()
    {
        id = 0;
        ord = 0;
    }
    
    public void ParIdOrd(long id, long ord)
    {
        this.id = id;
        this.ord = ord;
    }
    
    public void ParIdOrd(ParIdOrd par)
    {
        this.id = par.getId();
        this.ord = par.getOrd();
    }

    //getters
    public long getId()
    {
        return this.id;
    }
    
    public long getOrd()
    {
        return this.ord;
    }
    
    //setters
    public void setId(long id)
    {
        this.id = id;
    }
    
    public void setOrd(long ord)
    {
        this.ord = ord;
    }

    @Override  
    public int compareTo(ParIdOrd comp) {
        long compareOrd = (((ParIdOrd)comp).getOrd());
        return (int) (compareOrd - this.ord);
    }
}
