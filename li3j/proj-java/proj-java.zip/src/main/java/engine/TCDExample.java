package engine;


import BaseDeDados.*;
import Utilizadores.*;
import Posts.*;
import common.MyLog;
import common.Pair;
import li3.TADCommunity;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

public class TCDExample implements TADCommunity {

    private MyLog qelog;
    private BaseDeDados bd;
    
    /*
    public void init() {
        this.qelog = new MyLog("queryengine");
       	bd = new BaseDeDados();
    }*/
    

    public void load(String dumpPath) {
    	this.bd = new BaseDeDados();
    	this.bd.loadBD(dumpPath);
    }

    // Query 1
    public Pair<String,String> infoFromPost(long id) {
		Resposta resposta = null;
		Pergunta pergunta;
		Utilizador utilizador;
		HashPerguntas hashPergundas = bd.getHashPerguntas();
		HashRespostas hashRespostas = bd.getHashRespostas();
		HashUtilizadores hashUtilizadores = bd.getHashUtilizadores();
		if(hashRespostas.existeResposta(id)) resposta = hashRespostas.getResposta(id);   //verifica se é resposta
		if(resposta!=null) {
			pergunta = hashPergundas.getPergunta(resposta.getParentid());                //caso o id seja duma resposta vai buscar a pergunta correspondente
		} else {
			pergunta = hashPergundas.getPergunta(id);                                    //caso seja id duma pergunta vai buscar a pergunta
		}
		utilizador = hashUtilizadores.getUtilizador(pergunta.getOwner());                //get utilizador que fez a pergunta!
		String owner = utilizador.getDisplayName();                                      
		String title = pergunta.getTitle();
        return new Pair<>(title, owner);
    }

    // Query 2
    public List<Long> topMostActive(int N) {
    	ListaParIdOrd listaUtilTotalPosts = bd.getListaUtilTotalPosts();                 //lista de todos utilizadores ordenados por total de posts!
    	List<Long> res = new ArrayList<Long>();                                          //lista a ser preenchida com os N mais activos dentro do ciclo for
		int i = 0;
		for(ParIdOrd par : listaUtilTotalPosts.getListaParIdOrd())
		{
			res.add(par.getId());
			i++;
			if (i==N) break;
		}
        return res;
    }

    // Query 3
    public Pair<Long,Long> totalPosts(LocalDate begin, LocalDate end) {
    	/* TreeMaps de perguntas e datas que utilizam como key a data e guardam uma lista de ids das perguntas/respostas nessa data */
		TreeMapPosts treePergsDate = bd.getTreePergsDate();
		TreeMapPosts treeRespsDate = bd.getTreeRespsDate();
		LocalDate dateTemp = begin;
		int totalResp = 0;
		int totalPerg = 0;
		/* Ciclo que corre as datas no intervalo, como o value é uma lista o seu tamanho é o total de perguntas/respostas do dia,
		basta entao adicionar o seu tamnho ao total de respostas/perguntas */
		while(dateTemp.isBefore(end.plusDays(1))) {
			totalResp += treeRespsDate.getListaIds(dateTemp).size();
			totalPerg += treePergsDate.getListaIds(dateTemp).size();
			dateTemp = dateTemp.plusDays(1);
		}

        return new Pair<>((long) totalPerg,(long) totalResp);
    }

    // Query 4
    public List<Long> questionsWithTag(String tag, LocalDate begin, LocalDate end) {
		TreeMapPosts treePergsDate = bd.getTreePergsDate();
		LocalDate dateTemp = end;
		HashPerguntas hashPerguntas = bd.getHashPerguntas();
		List<Long> listaIds;
		List<Long> res = new ArrayList<Long>();
		Pergunta pergunta;

		while (dateTemp.isAfter(begin.plusDays(-1))) {
			listaIds = treePergsDate.getListaIds(dateTemp);
			for (long tempid : listaIds) {
				pergunta = hashPerguntas.getPergunta(tempid);
				if( pergunta.getTags().contains(tag)) res.add(tempid);
			}
			dateTemp=dateTemp.plusDays(-1);
		}
        return res;
    }

    // Query 5
    public Pair<String, List<Long>> getUserInfo(long id) {
    	HashUtilizadores hashUtilizadores = bd.getHashUtilizadores();
		Utilizador utilizador = hashUtilizadores.getUtilizador(id);
		String aboutMe = utilizador.getAboutMe();

		ListaParIdDate listaPerguntas = utilizador.getListaPerguntas();
		ListaParIdDate listaRespostas = utilizador.getListaRespostas();

		List<Long> listRes = listaPerguntas.getLastN(listaRespostas, 10);    //devolve as ultimas N(10 neste caso) perguntas da junção das duas listas

        return new Pair<>(aboutMe,listRes);
    }

    // Query 6
    public List<Long> mostVotedAnswers(int N, LocalDate begin, LocalDate end) {
    	TreeMapPosts treeRespsDate = bd.getTreeRespsDate();
		HashRespostas hashRespostas = bd.getHashRespostas();
		HashPerguntas hashPerguntas = bd.getHashPerguntas();
		Pergunta pergunta;
		Resposta resposta;
		LocalDate dateTemp = begin;
		List<Long> listaIds;
		ListaParIdOrd retList = new ListaParIdOrd();
		ParIdOrd par;
		while(dateTemp.isBefore(end.plusDays(1))) {  /* Sem verificar as perguntas da igual aos resultados de referencia, 
														na faq diz que as perguntas tem de estar no intervalo */
			listaIds = treeRespsDate.getListaIds(dateTemp);
			for(long tempid : listaIds) {
				resposta = hashRespostas.getResposta(tempid);	
				par = new ParIdOrd();
				par.setId(resposta.getId());
				par.setOrd(resposta.getScore());
				retList.inserirNovoParIdOrd(par);
			}
			dateTemp=dateTemp.plusDays(1);
		}
		retList.sortListaParIdOrd();
		List<ParIdOrd> returnList = retList.getListaParIdOrd();
		int i=0;
		List<Long> ret = new ArrayList<Long>();
		for(ParIdOrd parTemp : returnList) {
			if (i==N) break;
			i++;
			ret.add(parTemp.getId());
		}
        return ret;
    }

    // auxiliar query 7 conta as respostas duma pergunta num determinado intervalo de tempo!
    private long contaRespostas(Pergunta p, LocalDate begin, LocalDate end) {
    	HashRespostasPorPergunta hashListaRespostas = bd.getHashRespostasPorPergunta();
    	HashRespostas hashRespostas = bd.getHashRespostas();
    	Resposta resposta;
    	if (!hashListaRespostas.containsKey(p.getId())) return 0;
    	List<Long> listaIds = hashListaRespostas.getListaIds(p.getId());
    	long ret = 0;
    	for (long tempid : listaIds) {
    		resposta = hashRespostas.getResposta(tempid);
    		if(resposta.getCreationDate().isBefore(end.plusDays(1)) && resposta.getCreationDate().isAfter(begin.plusDays(-1))) ret++;
    		//ret++; SEM VERIFICAR A DATA FAZENDO APENAS ret++ resultado final == aos de referência!
    	}
    	return ret;
    }

    // Query 7
    public List<Long> mostAnsweredQuestions(int N, LocalDate begin, LocalDate end) {
		TreeMapPosts treePergsDate = bd.getTreePergsDate();
		HashPerguntas hashPerguntas = bd.getHashPerguntas();
		Pergunta pergunta;
		LocalDate dateTemp = begin;
		List<Long> listaIds;
		ListaParIdOrd retList = new ListaParIdOrd();
		ParIdOrd par;
		long numResps;
		while(dateTemp.isBefore(end.plusDays(1))) {             // sobre resultados apontamentos na auxiliar contaRespostas!
			listaIds = treePergsDate.getListaIds(dateTemp);
			for(long tempid : listaIds) {
				pergunta = hashPerguntas.getPergunta(tempid);
				numResps = contaRespostas(pergunta, begin, end);
				par = new ParIdOrd();
				par.setId(pergunta.getId());
				par.setOrd(numResps);
				retList.inserirNovoParIdOrd(par);
			}
			dateTemp = dateTemp.plusDays(1);
		}
		retList.sortListaParIdOrd();
		List<ParIdOrd> returnList = retList.getListaParIdOrd();
		int i=0;
		List<Long> ret = new ArrayList<Long>();
		for(ParIdOrd parTemp : returnList) {
			if (i==N) break;
			i++;
			ret.add(parTemp.getId());
		}
        return ret;
    }

    // Query 8
    public List<Long> containsWord(int N, String word) {
    	HashPerguntas hashPerguntas = bd.getHashPerguntas();
    	int i = 0;
    	TreeMapPosts tree =  bd.getTreePergsDate();
		LocalDate date = tree.getLastKey();
		List<Long> ret = new ArrayList<Long>();
		List<Long> listaIds;
		Pergunta perg;
		while (i<N) {
			listaIds = tree.getListaIds(date);
			for (long pergId : listaIds) {
				if(i==N) return ret;
				perg = hashPerguntas.getPergunta(pergId);
				if (perg.getTitle().contains(word)) {
					ret.add(pergId);
					i++;
				}
			}
			date = date.plusDays(-1);
		}

		return ret;
    }

    // auxiliar de query 10 verifica se um utilizador respondeu a uma pergunta
    public boolean participa(long pergid, long userid) {
    	HashRespostasPorPergunta hashRespostasPorPergunta = bd.getHashRespostasPorPergunta();
    	if(!hashRespostasPorPergunta.containsKey(pergid)) return false;
    	List<Long> listaIds = hashRespostasPorPergunta.getListaIds(pergid);
    	HashRespostas hashRespostas = bd.getHashRespostas();
    	Resposta resposta;
    	for (long tempid : listaIds) {
    		resposta = hashRespostas.getResposta(tempid);
    		if (resposta.getOwner() == userid) return true;
    	}
    	return false;
    }

    // Query 9
    public List<Long> bothParticipated(int N, long id1, long id2) {
    	ListaParIdDate listaResultado = new ListaParIdDate();
    	HashUtilizadores hashUtilizadores = bd.getHashUtilizadores();
    	ListaParIdDate listaPerguntas;
    	Utilizador utilizador1 = hashUtilizadores.getUtilizador(id1);
    	Utilizador utilizador2 = hashUtilizadores.getUtilizador(id2);

    	/* Vai buscar a lista de perguntas de cada utilizador, em seguida, para poder iterar vai buscar como List<>
    	   Durante o ciclo, para cada pergunta verifica se o outro utilizador participa, usando a funçao auxiliar participa,
    	   caso participe adiciona  a uma lista resultado que irá ser ordenada depois*/
    	listaPerguntas = utilizador1.getListaPerguntas();
    	List<ParIdDate> listaPerguntasDate = listaPerguntas.getListaParIdDate();
    	for (ParIdDate par : listaPerguntasDate) {
    		if(participa(par.getId(), id2)) listaResultado.inserirNovoParIdDate(par);
    	}

    	listaPerguntas = utilizador2.getListaPerguntas();
    	listaPerguntasDate = listaPerguntas.getListaParIdDate();
    	for (ParIdDate par : listaPerguntasDate) {
    		if(participa(par.getId(), id1)) listaResultado.inserirNovoParIdDate(par);
    	}

    	List<Long> ret = listaResultado.getIdsOrdenados();

        return ret;
    }

    // Query 10
    public long betterAnswer(long id) {
    	HashRespostasPorPergunta hashListaRespostas = bd.getHashRespostasPorPergunta();
    	if (!hashListaRespostas.containsKey(id)) return -1;
    	List<Long> listaIds = hashListaRespostas.getListaIds(id);
    	HashRespostas hashRespostas = bd.getHashRespostas();
    	HashUtilizadores hashUtilizadores = bd.getHashUtilizadores();
    	long respid = listaIds.get(0);
    	Resposta resposta = hashRespostas.getResposta(respid);
    	Utilizador utilizador = hashUtilizadores.getUtilizador(resposta.getOwner());
    	long better = listaIds.get(0);
    	double betterScore = (resposta.getScore() * 0.65) + (resposta.getComCount() * 0.1) + (utilizador.getReputation());
		for(Long tempid : listaIds) {
			resposta = hashRespostas.getResposta(tempid);
    		utilizador = hashUtilizadores.getUtilizador(resposta.getOwner());
    		if ( betterScore < ((resposta.getScore() * 0.65) + (resposta.getComCount() * 0.1) + (utilizador.getReputation())) ) {
    			betterScore = (resposta.getScore() * 0.65) + (resposta.getComCount() * 0.1) + (utilizador.getReputation());
    			better = tempid;
    		}
		}
        return better;
    }

    // Query 11
    public List<Long> mostUsedBestRep(int N, LocalDate begin, LocalDate end) {
        return Arrays.asList(6L,29L,72L,163L,587L);
    }

    public void clear(){

    }
}
