package Posts;

import java.time.LocalDate;
import java.util.StringTokenizer;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

public class HashRespostasPorPergunta 
{
	HashMap<Long,List<Long>> hash;

	public HashRespostasPorPergunta(){
		this.hash = new HashMap<Long,List<Long>>();
	}

	public List<Long> getListaIds(Long key) {
		return this.hash.get(key);
	}

	public boolean containsKey(Long key) {
		return this.hash.containsKey(key);
	}

	public void adicionaListaIds (Long key, List<Long> listaIds) {
		this.hash.put(key, listaIds);
	}
}
