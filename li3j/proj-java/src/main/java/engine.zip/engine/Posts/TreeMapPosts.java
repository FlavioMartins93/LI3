package Posts;

import java.time.LocalDate;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.Map;
import java.util.List;

public class TreeMapPosts 
{
	TreeMap<LocalDate,List<Long>> tree;

	public TreeMapPosts(){
		this.tree = new TreeMap<LocalDate,List<Long>>();
	}

	public List<Long> getListaIds(LocalDate key) {
		return this.tree.get(key);
	}

	public boolean containsKey(LocalDate key) {
		return this.tree.containsKey(key);
	}

	public void adicionaListaIds(LocalDate key, List<Long> listaIds) {
		this.tree.put(key, listaIds);
	}

	public LocalDate getLastKey() {
		return this.tree.lastKey();
	}

}
