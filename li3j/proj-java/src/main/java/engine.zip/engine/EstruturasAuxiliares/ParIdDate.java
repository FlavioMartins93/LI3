package EstruturasAuxiliares;

import java.lang.Object;
import java.time.LocalDate;

/**
 * classe que define um par contendo o Id e data de um post
 * 
 * @author Flavio Martins, Mario Santos, Pedro Costa 
 * @version 1.0
 */
public class ParIdDate implements Comparable<ParIdDate>
{
    // variáveis de instância
    private long id;                         //id do post
    private LocalDate date;                  //data de criação do post

    /**
     * COnstrutor para objetos da classe ParIdDate
     */
    public ParIdDate()
    {
        id = 0;
        date = null;
    }
    
    public ParIdDate(long id, LocalDate date)
    {
        this.id = id;
        this.date = date;
    }
    
    public ParIdDate(ParIdDate par)
    {
        this.id = par.getId();
        this.date = par.getDate();
    }

    //getters
    public long getId()
    {
        return this.id;
    }
    
    public LocalDate getDate()
    {
        return this.date;
    }
    
    //setters
    public void setId(long id)
    {
        this.id = id;
    }
    
    public void setDate(LocalDate date)
    {
        this.date = date;
    }

    public ParIdDate clone() 
    {
        return new ParIdDate(this);
    }

    @Override  
    public int compareTo(ParIdDate comp) {
        return -this.date.compareTo(comp.getDate());
    }
}
