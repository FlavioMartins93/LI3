package BaseDeDados;

import Utilizadores.*;
import Posts.*;
import EstruturasAuxiliares.*;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

public class BaseDeDados {

    HashUtilizadores hashUtilizadores;                     /* hashMap dos utilizadores */
    HashPerguntas hashPerguntas;                           /* hashMap das perguntas */
    HashRespostas hashRespostas;                           /* hashMap das respostas*/
    HashRespostasPorPergunta hashRespostasPorPergunta;     /* hashMap de uma lista com os ids das respostas de cada pergunta */
    ListaParIdOrd listaUtilRep;                            /* lista de ids de utilizador ordenada por reputação */
    ListaParIdOrd listaUtilTotPosts;                       /* lista de ids de utilizador ordenada por total de posts */
    TreeMapPosts treePergsDate;                            /* treeMap com a data como key e uma lista de ids das perguntas de cada dia*/
    TreeMapPosts treeRespsDate;                            /* treeMap com a data como key e uma lista de ids das respostas de cada dia*/
    HashMap hashTags;                                      /* hashMap de tags e respectivo identificador */


    public BaseDeDados() 
    {
        this.hashUtilizadores = new HashUtilizadores();
        this.hashPerguntas = new HashPerguntas();
        this.hashRespostas = new HashRespostas();
        this.hashRespostasPorPergunta = new HashRespostasPorPergunta();
        this.listaUtilRep = new ListaParIdOrd();
        this.listaUtilTotPosts = new ListaParIdOrd();
        this.treePergsDate = new TreeMapPosts();
        this.treeRespsDate = new TreeMapPosts();
        this.hashTags = new HashMap<String,Long>();
    }


    public HashUtilizadores getHashUtilizadores() { return this.hashUtilizadores;}
    public HashPerguntas getHashPerguntas() { return this.hashPerguntas;}
    public HashRespostas getHashRespostas() { return this.hashRespostas;}
    public HashRespostasPorPergunta getHashRespostasPorPergunta() { return this.hashRespostasPorPergunta;}
    public ListaParIdOrd getListaUtilRep() { return this.listaUtilRep;}
    public ListaParIdOrd getListaUtilTotalPosts() { return this.listaUtilTotPosts;}
    public TreeMapPosts getTreePergsDate() { return this.treePergsDate;}
    public TreeMapPosts getTreeRespsDate() { return this.treeRespsDate;}
    public HashMap getHashTags() { return this.hashTags;}

    public void loadBD(String dump_path) {
        
        this.Parsefiles(dump_path);

        this.listaUtilTotPosts = this.hashUtilizadores.getListaUtilPosts();
        this.listaUtilTotPosts.sortListaParIdOrd();
    }

    public void Parsefiles(String dump_path) {

        SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();

        try {
            SAXParser saxParser = saxParserFactory.newSAXParser();
            ParseUtilizadores handler = new ParseUtilizadores();
            String pathU = (dump_path + "Users.xml");
            saxParser.parse(new File(pathU), handler);
            this.hashUtilizadores = handler.getUtilHash();
            this.listaUtilRep = handler.getListaUtilRep();
            this.listaUtilRep.sortListaParIdOrd();
        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }

        try {
            SAXParser saxParser = saxParserFactory.newSAXParser();
            ParsePosts handler = new ParsePosts();
            handler.setHashUtil(this.hashUtilizadores);
            String pathP = (dump_path + "Posts.xml");
            saxParser.parse(new File(pathP), handler);
            this.hashPerguntas = handler.getHashPerg();
            this.hashRespostas = handler.getHashResp();
            this.hashUtilizadores = handler.getHashUtil();
            this.hashRespostasPorPergunta = handler.getHashRespostasPorPergunta();
            this.treeRespsDate  = handler.getTreeRespsDate();
            this.treePergsDate = handler.getTreePergsDate();
        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }

        try {
            SAXParser saxParser = saxParserFactory.newSAXParser();
            ParseVotes handler = new ParseVotes();
            handler.setHashRespostas(this.hashRespostas);
            String pathV = (dump_path + "Votes.xml");
            saxParser.parse(new File(pathV), handler);
            this.hashRespostas = handler.getHashRespostas();
        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }

        try {
            SAXParser saxParser = saxParserFactory.newSAXParser();
            ParseTags handler = new ParseTags();
            String pathT = (dump_path + "Tags.xml");
            saxParser.parse(new File(pathT), handler);
            this.hashTags = handler.getHashTags();
        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }
    }
}
